# Reward Bin (Forge 1.20.1)

## Compilar
1. Descarga el MDK de Forge 1.20.1 (47.3.0) desde files.minecraftforge.net.
2. Copia de ese MDK a esta carpeta: `gradlew`, `gradlew.bat` y la carpeta `gradle/`.
3. Necesitas JDK 17.
4. `./gradlew build`  -> el jar queda en `build/libs/`.
5. Para probar: `./gradlew runClient`.

## Probar rapido
- `/rewardbin add 49` (op) y luego tira 1 objeto -> recompensa.
- `/rewardbin stats` muestra tu progreso.

## Configuracion
`config/rewardbin-common.toml`: objetos por recompensa, por nivel, probabilidad de objeto aleatorio de mods,
y lista negra de objetos/mods.

## Datapack
- Recompensas por nivel: `data/rewardbin/loot_tables/rewards/tier_0..tier_10.json`
- Tags: `rare_rewards`, `luxury`, `random_blacklist` en `data/rewardbin/tags/items/`
