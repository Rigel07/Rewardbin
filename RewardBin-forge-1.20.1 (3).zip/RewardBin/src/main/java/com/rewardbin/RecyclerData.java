package com.rewardbin;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.util.LazyOptional;

/**
 * Datos persistentes del jugador. Solo guardamos el total de objetos tirados;
 * el nivel y el progreso se deducen de ahi.
 */
public class RecyclerData {
    public static final Capability<RecyclerData> CAP = CapabilityManager.get(new CapabilityToken<>() {});

    private long total;
    private int rewards;
    private int rareRewards;
    private int modRewards;
    private boolean luxury;

    public long getTotal() { return total; }
    public int getRewards() { return rewards; }
    public int getRareRewards() { return rareRewards; }
    public int getModRewards() { return modRewards; }
    public boolean hasLuxury() { return luxury; }

    public void addTotal(long amount) { total += amount; }
    public void setLuxury(boolean value) { luxury = value; }

    public void addReward(boolean rare, boolean fromMods) {
        rewards++;
        if (rare) rareRewards++;
        if (fromMods) modRewards++;
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putLong("total", total);
        tag.putInt("rewards", rewards);
        tag.putInt("rare", rareRewards);
        tag.putInt("mods", modRewards);
        tag.putBoolean("luxury", luxury);
        return tag;
    }

    public void load(CompoundTag tag) {
        total = tag.getLong("total");
        rewards = tag.getInt("rewards");
        rareRewards = tag.getInt("rare");
        modRewards = tag.getInt("mods");
        luxury = tag.getBoolean("luxury");
    }

    public void copyFrom(RecyclerData other) {
        load(other.save());
    }

    public static LazyOptional<RecyclerData> of(Player player) {
        return player.getCapability(CAP);
    }
}
