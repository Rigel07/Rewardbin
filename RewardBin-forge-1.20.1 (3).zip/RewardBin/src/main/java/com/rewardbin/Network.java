package com.rewardbin;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class Network {
    private static final String VERSION = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(RewardBinMod.MODID, "main"),
            () -> VERSION, VERSION::equals, VERSION::equals);

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, TrashPacket.class, TrashPacket::encode, TrashPacket::decode, TrashPacket::handle);
        CHANNEL.registerMessage(id++, SyncPacket.class, SyncPacket::encode, SyncPacket::decode, SyncPacket::handle);
    }

    public static void sync(ServerPlayer player, RecyclerData data) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                new SyncPacket(data.getTotal(), Config.ITEMS_PER_REWARD.get(), Config.ITEMS_PER_LEVEL.get()));
    }

    private Network() {}
}
