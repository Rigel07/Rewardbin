package com.rewardbin;

import java.util.List;

import net.minecraftforge.common.ForgeConfigSpec;

public final class Config {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue ITEMS_PER_REWARD;
    public static final ForgeConfigSpec.IntValue ITEMS_PER_LEVEL;
    public static final ForgeConfigSpec.DoubleValue RANDOM_ITEM_CHANCE;
    public static final ForgeConfigSpec.BooleanValue INCLUDE_VANILLA_IN_RANDOM;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> RANDOM_BLACKLIST;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        ITEMS_PER_REWARD = b.comment("Objetos que hay que tirar para recibir una recompensa")
                .defineInRange("itemsPerReward", 50, 1, 100000);
        ITEMS_PER_LEVEL = b.comment("Objetos que hay que tirar para subir un nivel de reciclaje")
                .defineInRange("itemsPerLevel", 1000, 1, 10000000);
        RANDOM_ITEM_CHANCE = b.comment("Probabilidad (0.0 - 1.0) de que la recompensa sea un objeto aleatorio de los mods en vez del loot table del nivel")
                .defineInRange("randomItemChance", 0.3D, 0.0D, 1.0D);
        INCLUDE_VANILLA_IN_RANDOM = b.comment("Si es true, el objeto aleatorio tambien puede ser de Minecraft vanilla")
                .define("includeVanillaInRandom", false);
        RANDOM_BLACKLIST = b.comment("Objetos que nunca saldran como recompensa aleatoria. Admite 'modid:item', 'modid:*' o 'modid'")
                .defineListAllowEmpty("randomItemBlacklist", List.of(), o -> o instanceof String);

        SPEC = b.build();
    }

    private Config() {}
}
