package com.rewardbin;

import java.util.function.Supplier;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** Cliente -> servidor: tirar el objeto que lleva el cursor. */
public class TrashPacket {
    private final boolean single;

    public TrashPacket(boolean single) {
        this.single = single;
    }

    public static void encode(TrashPacket p, FriendlyByteBuf buf) {
        buf.writeBoolean(p.single);
    }

    public static TrashPacket decode(FriendlyByteBuf buf) {
        return new TrashPacket(buf.readBoolean());
    }

    public static void handle(TrashPacket p, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer player = c.getSender();
            if (player != null) {
                RecyclerLogic.trash(player, p.single);
            }
        });
        c.setPacketHandled(true);
    }
}
