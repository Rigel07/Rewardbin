package com.rewardbin;

import com.google.gson.JsonObject;

import net.minecraft.advancements.critereon.AbstractCriterionTriggerInstance;
import net.minecraft.advancements.critereon.ContextAwarePredicate;
import net.minecraft.advancements.critereon.DeserializationContext;
import net.minecraft.advancements.critereon.SerializationContext;
import net.minecraft.advancements.critereon.SimpleCriterionTrigger;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.GsonHelper;

/**
 * Criterio propio "rewardbin:milestone". Condiciones (todas opcionales, minimos):
 * total, level, rewards, rare, mods, luxury.
 */
public class MilestoneTrigger extends SimpleCriterionTrigger<MilestoneTrigger.Instance> {
    public static final ResourceLocation ID = new ResourceLocation(RewardBinMod.MODID, "milestone");
    public static final MilestoneTrigger INSTANCE = new MilestoneTrigger();

    @Override
    public ResourceLocation getId() {
        return ID;
    }

    @Override
    protected Instance createInstance(JsonObject json, ContextAwarePredicate player, DeserializationContext ctx) {
        return new Instance(player,
                GsonHelper.getAsLong(json, "total", 0L),
                GsonHelper.getAsInt(json, "level", 0),
                GsonHelper.getAsInt(json, "rewards", 0),
                GsonHelper.getAsInt(json, "rare", 0),
                GsonHelper.getAsInt(json, "mods", 0),
                GsonHelper.getAsBoolean(json, "luxury", false));
    }

    public void trigger(ServerPlayer player, RecyclerData data, int level) {
        trigger(player, inst -> inst.matches(data, level));
    }

    public static class Instance extends AbstractCriterionTriggerInstance {
        private final long total;
        private final int level;
        private final int rewards;
        private final int rare;
        private final int mods;
        private final boolean luxury;

        public Instance(ContextAwarePredicate player, long total, int level, int rewards, int rare, int mods, boolean luxury) {
            super(ID, player);
            this.total = total;
            this.level = level;
            this.rewards = rewards;
            this.rare = rare;
            this.mods = mods;
            this.luxury = luxury;
        }

        public boolean matches(RecyclerData d, int currentLevel) {
            return d.getTotal() >= total
                    && currentLevel >= level
                    && d.getRewards() >= rewards
                    && d.getRareRewards() >= rare
                    && d.getModRewards() >= mods
                    && (!luxury || d.hasLuxury());
        }

        @Override
        public JsonObject serializeToJson(SerializationContext ctx) {
            JsonObject json = super.serializeToJson(ctx);
            json.addProperty("total", total);
            json.addProperty("level", level);
            json.addProperty("rewards", rewards);
            json.addProperty("rare", rare);
            json.addProperty("mods", mods);
            json.addProperty("luxury", luxury);
            return json;
        }
    }
}
