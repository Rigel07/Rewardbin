package com.rewardbin;

import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, RewardBinMod.MODID);

    /** Solo se usa como icono (interfaz y logros). No sale en ninguna pestaña creativa ni como recompensa. */
    public static final RegistryObject<Item> BIN_ICON = ITEMS.register("bin_icon", () -> new Item(new Item.Properties()));

    private ModItems() {}
}
