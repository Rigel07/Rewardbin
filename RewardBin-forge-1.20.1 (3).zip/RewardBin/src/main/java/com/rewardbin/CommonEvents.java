package com.rewardbin;

import com.mojang.brigadier.arguments.IntegerArgumentType;

import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public final class CommonEvents {
    private static final ResourceLocation CAP_ID = new ResourceLocation(RewardBinMod.MODID, "recycler");

    @Mod.EventBusSubscriber(modid = RewardBinMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class ModBus {
        @SubscribeEvent
        public static void registerCaps(RegisterCapabilitiesEvent event) {
            event.register(RecyclerData.class);
        }
    }

    @Mod.EventBusSubscriber(modid = RewardBinMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static final class ForgeBus {
        @SubscribeEvent
        public static void attach(AttachCapabilitiesEvent<Entity> event) {
            if (event.getObject() instanceof Player) {
                event.addCapability(CAP_ID, new RecyclerProvider());
            }
        }

        /** Mantiene los datos al morir o volver del End. */
        @SubscribeEvent
        public static void clone(PlayerEvent.Clone event) {
            event.getOriginal().reviveCaps();
            RecyclerData.of(event.getOriginal()).ifPresent(old ->
                    RecyclerData.of(event.getEntity()).ifPresent(fresh -> fresh.copyFrom(old)));
            event.getOriginal().invalidateCaps();
        }

        @SubscribeEvent
        public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
            sync(event.getEntity());
        }

        @SubscribeEvent
        public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
            sync(event.getEntity());
        }

        @SubscribeEvent
        public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
            sync(event.getEntity());
        }

        private static void sync(Player player) {
            if (player instanceof ServerPlayer sp) {
                RecyclerData.of(sp).ifPresent(data -> Network.sync(sp, data));
            }
        }

        @SubscribeEvent
        public static void commands(RegisterCommandsEvent event) {
            event.getDispatcher().register(Commands.literal("rewardbin")
                    .then(Commands.literal("stats").executes(ctx -> {
                        ServerPlayer p = ctx.getSource().getPlayerOrException();
                        RecyclerData.of(p).ifPresent(d -> {
                            long perLevel = Config.ITEMS_PER_LEVEL.get();
                            ctx.getSource().sendSuccess(() -> Component.translatable("command.rewardbin.stats",
                                    d.getTotal(), d.getTotal() / perLevel, d.getRewards(), d.getRareRewards()), false);
                        });
                        return 1;
                    }))
                    .then(Commands.literal("add").requires(s -> s.hasPermission(2))
                            .then(Commands.argument("amount", IntegerArgumentType.integer(1, 1000000))
                                    .executes(ctx -> {
                                        ServerPlayer p = ctx.getSource().getPlayerOrException();
                                        int amount = IntegerArgumentType.getInteger(ctx, "amount");
                                        RecyclerLogic.addTrashed(p, amount, false);
                                        ctx.getSource().sendSuccess(() -> Component.translatable("command.rewardbin.add", amount), false);
                                        return 1;
                                    }))));
        }
    }

    private CommonEvents() {}
}
