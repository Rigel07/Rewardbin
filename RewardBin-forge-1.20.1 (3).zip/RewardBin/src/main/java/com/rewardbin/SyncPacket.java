package com.rewardbin;

import java.util.function.Supplier;

import com.rewardbin.client.ClientRecyclerData;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

/** Servidor -> cliente: estado de la papelera para dibujar la interfaz. */
public class SyncPacket {
    private final long total;
    private final int perReward;
    private final int perLevel;

    public SyncPacket(long total, int perReward, int perLevel) {
        this.total = total;
        this.perReward = perReward;
        this.perLevel = perLevel;
    }

    public static void encode(SyncPacket p, FriendlyByteBuf buf) {
        buf.writeLong(p.total);
        buf.writeInt(p.perReward);
        buf.writeInt(p.perLevel);
    }

    public static SyncPacket decode(FriendlyByteBuf buf) {
        return new SyncPacket(buf.readLong(), buf.readInt(), buf.readInt());
    }

    public static void handle(SyncPacket p, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        // ClientRecyclerData no importa ninguna clase de cliente, es seguro en servidor dedicado.
        c.enqueueWork(() -> ClientRecyclerData.set(p.total, p.perReward, p.perLevel));
        c.setPacketHandled(true);
    }
}
