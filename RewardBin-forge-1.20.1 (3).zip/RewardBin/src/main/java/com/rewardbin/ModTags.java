package com.rewardbin;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;

public final class ModTags {
    /** Recompensas que cuentan como "raras" (logros). */
    public static final TagKey<Item> RARE_REWARDS = tag("rare_rewards");
    /** Objetos muy valiosos: tirarlos desbloquea el logro secreto. */
    public static final TagKey<Item> LUXURY = tag("luxury");
    /** Objetos que nunca saldran en la recompensa aleatoria. */
    public static final TagKey<Item> RANDOM_BLACKLIST = tag("random_blacklist");

    private static TagKey<Item> tag(String name) {
        return TagKey.create(Registries.ITEM, new ResourceLocation(RewardBinMod.MODID, name));
    }

    private ModTags() {}
}
