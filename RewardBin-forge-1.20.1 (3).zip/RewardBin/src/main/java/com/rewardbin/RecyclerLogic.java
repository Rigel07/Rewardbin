package com.rewardbin;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraftforge.registries.ForgeRegistries;

public final class RecyclerLogic {
    /** Hay loot tables rewards/tier_0 ... rewards/tier_10; niveles mayores usan el tier_10. */
    private static final int MAX_TIER = 10;

    /** Llamado desde el paquete del cliente. Toda la validacion ocurre aqui, en el servidor. */
    public static void trash(ServerPlayer player, boolean single) {
        AbstractContainerMenu menu = player.containerMenu;
        if (menu != player.inventoryMenu) return;

        ItemStack carried = menu.getCarried();
        if (carried.isEmpty()) return;

        int amount = single ? 1 : carried.getCount();
        boolean luxury = carried.is(ModTags.LUXURY);

        if (amount >= carried.getCount()) {
            menu.setCarried(ItemStack.EMPTY);
        } else {
            carried.shrink(amount);
        }
        menu.broadcastChanges();

        addTrashed(player, amount, luxury);
    }

    /** Suma objetos al contador, entrega recompensas, sube de nivel y sincroniza. */
    public static void addTrashed(ServerPlayer player, int amount, boolean luxury) {
        RecyclerData.of(player).ifPresent(data -> {
            long perReward = Config.ITEMS_PER_REWARD.get();
            long perLevel = Config.ITEMS_PER_LEVEL.get();

            long before = data.getTotal();
            data.addTotal(amount);
            long after = data.getTotal();
            if (luxury) data.setLuxury(true);

            long rewardsDue = after / perReward - before / perReward;
            for (long i = 1; i <= rewardsDue; i++) {
                long reachedAt = (before / perReward + i) * perReward;
                giveReward(player, data, (int) (reachedAt / perLevel));
            }

            int levelBefore = (int) (before / perLevel);
            int levelNow = (int) (after / perLevel);
            if (levelNow > levelBefore) {
                player.displayClientMessage(Component.translatable("message.rewardbin.levelup", levelNow)
                        .withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD), true);
                player.sendSystemMessage(Component.translatable("message.rewardbin.levelup", levelNow)
                        .withStyle(ChatFormatting.AQUA));
                player.level().playSound(null, player.blockPosition(), SoundEvents.PLAYER_LEVELUP,
                        SoundSource.PLAYERS, 1.0F, 1.0F);
            }

            Network.sync(player, data);
            MilestoneTrigger.INSTANCE.trigger(player, data, levelNow);
        });
    }

    private static void giveReward(ServerPlayer player, RecyclerData data, int level) {
        boolean fromMods = player.getRandom().nextDouble() < Config.RANDOM_ITEM_CHANCE.get();
        List<ItemStack> items = fromMods ? randomModItems(player, level) : lootItems(player, level);
        if (items.isEmpty()) {
            fromMods = !fromMods;
            items = fromMods ? randomModItems(player, level) : lootItems(player, level);
        }

        boolean rare = false;
        boolean any = false;
        for (ItemStack stack : items) {
            if (stack.isEmpty()) continue;
            any = true;
            rare |= isRare(stack);

            int count = stack.getCount();
            Component name = stack.getDisplayName();
            if (!player.getInventory().add(stack)) {
                player.drop(stack, false);
            }
            player.sendSystemMessage(Component.translatable(
                    fromMods ? "message.rewardbin.reward_random" : "message.rewardbin.reward", count, name)
                    .withStyle(rare ? ChatFormatting.GOLD : ChatFormatting.GREEN));
        }

        if (any) {
            data.addReward(rare, fromMods);
            player.level().playSound(null, player.blockPosition(),
                    rare ? SoundEvents.UI_TOAST_CHALLENGE_COMPLETE : SoundEvents.AMETHYST_BLOCK_CHIME,
                    SoundSource.PLAYERS, 1.0F, 1.0F);
        }
    }

    private static boolean isRare(ItemStack stack) {
        Rarity rarity = stack.getRarity();
        return stack.is(ModTags.RARE_REWARDS) || rarity == Rarity.RARE || rarity == Rarity.EPIC;
    }

    private static List<ItemStack> lootItems(ServerPlayer player, int level) {
        ServerLevel serverLevel = (ServerLevel) player.level();
        ResourceLocation id = new ResourceLocation(RewardBinMod.MODID, "rewards/tier_" + Math.min(level, MAX_TIER));
        LootTable table = serverLevel.getServer().getLootData().getLootTable(id);
        LootParams params = new LootParams.Builder(serverLevel)
                .withParameter(LootContextParams.ORIGIN, player.position())
                .withParameter(LootContextParams.THIS_ENTITY, player)
                .create(LootContextParamSets.GIFT);
        return new ArrayList<>(table.getRandomItems(params));
    }

    private static List<ItemStack> randomModItems(ServerPlayer player, int level) {
        boolean includeVanilla = Config.INCLUDE_VANILLA_IN_RANDOM.get();
        List<? extends String> blacklist = Config.RANDOM_BLACKLIST.get();

        List<Item> pool = new ArrayList<>();
        for (Item item : ForgeRegistries.ITEMS) {
            ResourceLocation key = ForgeRegistries.ITEMS.getKey(item);
            if (key == null || item == Items.AIR) continue;
            if (key.getNamespace().equals(RewardBinMod.MODID)) continue;
            if (!includeVanilla && key.getNamespace().equals("minecraft")) continue;
            if (isBlacklisted(key, blacklist)) continue;
            if (item.builtInRegistryHolder().is(ModTags.RANDOM_BLACKLIST)) continue;
            pool.add(item);
        }
        if (pool.isEmpty()) return List.of();

        Item pick = pool.get(player.getRandom().nextInt(pool.size()));
        int max = Math.max(1, Math.min(pick.getMaxStackSize(), 1 + level));
        int count = 1 + player.getRandom().nextInt(max);
        List<ItemStack> result = new ArrayList<>();
        result.add(new ItemStack(pick, count));
        return result;
    }

    private static boolean isBlacklisted(ResourceLocation key, List<? extends String> blacklist) {
        String full = key.toString();
        String ns = key.getNamespace();
        for (String entry : blacklist) {
            if (entry.equals(full) || entry.equals(ns) || entry.equals(ns + ":*")) return true;
        }
        return false;
    }

    private RecyclerLogic() {}
}
