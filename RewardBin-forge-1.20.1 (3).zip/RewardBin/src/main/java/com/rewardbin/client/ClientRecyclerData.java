package com.rewardbin.client;

/** Copia en el cliente del estado de la papelera (solo para dibujar la interfaz). */
public final class ClientRecyclerData {
    public static long total = 0;
    public static int perReward = 50;
    public static int perLevel = 1000;

    public static void set(long total, int perReward, int perLevel) {
        ClientRecyclerData.total = total;
        ClientRecyclerData.perReward = Math.max(1, perReward);
        ClientRecyclerData.perLevel = Math.max(1, perLevel);
    }

    private ClientRecyclerData() {}
}
