package com.rewardbin.client;

import java.util.List;

import com.rewardbin.ModItems;
import com.rewardbin.Network;
import com.rewardbin.RewardBinMod;
import com.rewardbin.TrashPacket;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = RewardBinMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ClientEvents {
    private static final int W = 26;
    private static final int H = 32;
    private static ItemStack icon;

    /** true si el clic actual empezo FUERA de la papelera con la mano vacia (posible arrastre). */
    private static boolean dragCandidate = false;

    // Posicion: a la derecha del inventario, pegada a la parte baja. Cambia aqui para moverla.
    private static int binX(AbstractContainerScreen<?> s) {
        return s.getGuiLeft() + s.getXSize() + 6;
    }

    private static int binY(AbstractContainerScreen<?> s) {
        return s.getGuiTop() + s.getYSize() - H;
    }

    private static boolean inside(AbstractContainerScreen<?> s, double mx, double my) {
        int x = binX(s);
        int y = binY(s);
        return mx >= x && mx < x + W && my >= y && my < y + H;
    }

    @SubscribeEvent
    public static void onRender(ScreenEvent.Render.Post event) {
        if (!(event.getScreen() instanceof InventoryScreen screen)) return;

        GuiGraphics g = event.getGuiGraphics();
        int x = binX(screen);
        int y = binY(screen);
        int mx = event.getMouseX();
        int my = event.getMouseY();
        boolean hover = inside(screen, mx, my);
        boolean holding = !screen.getMenu().getCarried().isEmpty();

        // Marco estilo inventario
        g.fill(x, y, x + W, y + H, 0xFF000000);
        g.fill(x + 1, y + 1, x + W - 1, y + H - 1, 0xFFC6C6C6);
        g.fill(x + 1, y + 1, x + W - 1, y + 2, 0xFFFFFFFF);
        g.fill(x + 1, y + 1, x + 2, y + H - 1, 0xFFFFFFFF);

        // Hueco del icono (se tiñe de rojo cuando llevas un objeto encima)
        int slotColor = holding ? (hover ? 0xFFD07070 : 0xFFA09090) : 0xFF8B8B8B;
        g.fill(x + 4, y + 4, x + 22, y + 22, slotColor);
        if (icon == null) icon = new ItemStack(ModItems.BIN_ICON.get());
        g.renderItem(icon, x + 5, y + 5);

        // Barra de progreso hacia la siguiente recompensa
        long per = ClientRecyclerData.perReward;
        long progress = ClientRecyclerData.total % per;
        int fill = (int) (20L * progress / per);
        g.fill(x + 3, y + 24, x + 23, y + 29, 0xFF373737);
        if (fill > 0) {
            g.fill(x + 3, y + 24, x + 3 + fill, y + 29, 0xFF55FF55);
        }

        if (hover) {
            long perLevel = ClientRecyclerData.perLevel;
            long total = ClientRecyclerData.total;
            List<Component> lines = List.of(
                    Component.translatable("gui.rewardbin.title").withStyle(ChatFormatting.GOLD),
                    Component.translatable("gui.rewardbin.level", total / perLevel).withStyle(ChatFormatting.AQUA),
                    Component.translatable("gui.rewardbin.progress", progress, per).withStyle(ChatFormatting.GREEN),
                    Component.translatable("gui.rewardbin.next_level", total % perLevel, perLevel).withStyle(ChatFormatting.YELLOW),
                    Component.translatable("gui.rewardbin.total", total).withStyle(ChatFormatting.GRAY),
                    Component.translatable("gui.rewardbin.hint").withStyle(ChatFormatting.DARK_GRAY),
                    Component.translatable("gui.rewardbin.hint_single").withStyle(ChatFormatting.DARK_GRAY));
            g.renderComponentTooltip(Minecraft.getInstance().font, lines, mx, my);
        }
    }

    @SubscribeEvent
    public static void onPress(ScreenEvent.MouseButtonPressed.Pre event) {
        if (!(event.getScreen() instanceof InventoryScreen screen)) return;

        boolean carriedEmpty = screen.getMenu().getCarried().isEmpty();
        if (!inside(screen, event.getMouseX(), event.getMouseY())) {
            dragCandidate = carriedEmpty;
            return;
        }

        dragCandidate = false;
        event.setCanceled(true); // evita que vanilla tire el objeto al suelo
        if (!carriedEmpty) {
            // Clic izquierdo: todo el stack. Clic derecho: solo uno.
            Network.CHANNEL.sendToServer(new TrashPacket(event.getButton() == 1));
        }
    }

    /** Arrastrar: pulsas sobre un objeto, lo llevas hasta la papelera y sueltas el boton. */
    @SubscribeEvent
    public static void onRelease(ScreenEvent.MouseButtonReleased.Pre event) {
        if (!(event.getScreen() instanceof InventoryScreen screen)) return;

        boolean candidate = dragCandidate;
        dragCandidate = false;

        if (candidate
                && inside(screen, event.getMouseX(), event.getMouseY())
                && !screen.getMenu().getCarried().isEmpty()) {
            Network.CHANNEL.sendToServer(new TrashPacket(false));
        }
        // No cancelamos el evento: vanilla necesita procesar su propio estado de "soltar".
    }

    private ClientEvents() {}
}
